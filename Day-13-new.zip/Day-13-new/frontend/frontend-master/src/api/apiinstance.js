import axios from 'axios';

const api = axios.create({
    baseURL: "http://localhost:8080"
    
})

//products/view
//auth/register
export default api;